# Wireguard AppIndicator
## Configuration
As of 2019.12.24, you must manually configure your interface name if it is not wg0 by modifying the script. In the future, I will make this a cleaner process.

## Usage
To use this indicator app, simply add the script to whatever file you use for startup applications, e.g. $HOME/.profile